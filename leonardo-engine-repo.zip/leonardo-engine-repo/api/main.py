from __future__ import annotations

from fastapi import FastAPI, File, Form, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from leonardo_engine.config import settings
from leonardo_engine.pipeline import LeonardoEngine

app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

engine = LeonardoEngine()


@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}


@app.post("/analyze")
async def analyze(
    text: str = Form(default=""),
    location: str = Form(default=""),
    image: UploadFile | None = File(default=None),
):
    image_obj = None
    if image is not None:
        content = await image.read()
        image_obj = content

    result = engine.analyze(text=text, location=location, image=image_obj)
    return result.to_response()

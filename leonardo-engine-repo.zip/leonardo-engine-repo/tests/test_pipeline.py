from leonardo_engine.pipeline import LeonardoEngine


def test_text_analysis():
    engine = LeonardoEngine()
    result = engine.analyze(text="Analyze a city as a living flow system")
    assert result.title
    assert "flow" in result.hidden_patterns.lower() or "flow" in result.leonardo_view.lower()
    assert result.generated_image_base64


def test_location_analysis():
    engine = LeonardoEngine()
    result = engine.analyze(location="Pune, India")
    assert "Pune" in result.spatial_snapshot
    assert result.generated_image_base64

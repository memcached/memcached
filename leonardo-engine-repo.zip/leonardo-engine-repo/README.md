# Leonardo Engine

A production-ready starting point for a geospatial and perceptual intelligence app inspired by the Leonardo-style framework: perception, compression, generation, simulation, and interaction.

This repository is structured to run in two modes:

1. **Hugging Face Space UI** via `app.py`
2. **FastAPI backend** via `api/main.py`

It is designed to support:
- image analysis
- text interpretation
- location-driven map analysis
- optional Google Maps Static API integration
- optional captioning and diffusion models when GPU resources are available

## Features

- Multi-modal input: text, image, or location
- Lightweight perception pipeline with optional ML upgrades
- Deterministic fallback generation when no GPU is available
- Google Maps Static API adapter for location views
- FastAPI endpoint for integrations
- Gradio UI for Hugging Face Spaces
- Tests for the core pipeline

## Project layout

```text
leonardo-engine/
├── app.py
├── api/
│   └── main.py
├── leonardo_engine/
│   ├── config.py
│   ├── generation.py
│   ├── maps.py
│   ├── perception.py
│   ├── pipeline.py
│   ├── schemas.py
│   ├── simulation.py
│   └── utils.py
├── tests/
│   └── test_pipeline.py
├── Dockerfile
├── requirements.txt
├── .env.example
└── README.md
```

## Quickstart

```bash
git clone <your-repo-url>
cd leonardo-engine
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn api.main:app --reload
```

Open:
- API docs: `http://127.0.0.1:8000/docs`
- UI: run `python app.py`

## Hugging Face Spaces

Use **Gradio** as the Space SDK and set the entry point to:

```bash
python app.py
```

## Environment variables

- `GOOGLE_MAPS_API_KEY`: enables Google Static Maps snapshots
- `ENABLE_DIFFUSION=1`: enables optional Stable Diffusion generation if installed and models are available
- `ENABLE_CAPTIONING=1`: enables optional image captioning if installed and models are available
- `DIFFUSION_MODEL_ID`: model id for text-to-image generation
- `CAPTIONING_MODEL_ID`: model id for captioning

## API

### `GET /health`
Returns a simple status payload.

### `POST /analyze`
Accepts `text`, `location`, or an uploaded `image`.

Example:

```json
{
  "text": "Analyze the flow structure of this district",
  "location": "Pune, India"
}
```

## Design choices

This implementation uses:
- **FastAPI** for predictable backend integration
- **Pydantic** for validation
- **Pillow + NumPy** for deterministic rendering
- **Optional Transformers / Diffusers** for richer ML paths

The result is practical on CPU-only environments while leaving a clear path to GPU acceleration.

## Next upgrades

- Add PostGIS-backed spatial storage
- Add vector search for urban memory
- Add real-time map tiles and route analytics
- Add multi-user annotation and collaboration
- Add AR overlays for camera-based location views

from __future__ import annotations

import gradio as gr

from leonardo_engine.config import settings
from leonardo_engine.pipeline import LeonardoEngine

engine = LeonardoEngine()


def analyze_ui(text, image, location):
    result = engine.analyze(text=text or "", image=image, location=location or "")
    visual = result.generated_image
    return (
        result.title,
        result.spatial_snapshot,
        result.hidden_patterns,
        result.leonardo_view,
        result.intervention_simulation,
        result.modern_layer_integration,
        visual,
    )


with gr.Blocks(title=settings.app_name) as demo:
    gr.Markdown(f"# {settings.app_name}

Perception → Compression → Generation → Simulation → Interaction")

    with gr.Row():
        with gr.Column(scale=1):
            text = gr.Textbox(label="Text prompt", placeholder="Analyze this city block as a living system")
            image = gr.Image(label="Image input", type="pil")
            location = gr.Textbox(label="Location", placeholder="Pune, India")
            run = gr.Button("Analyze", variant="primary")

        with gr.Column(scale=2):
            title = gr.Textbox(label="Title")
            spatial_snapshot = gr.Textbox(label="Spatial snapshot", lines=4)
            hidden_patterns = gr.Textbox(label="Hidden patterns", lines=4)
            leonardo_view = gr.Textbox(label="Leonardo view", lines=4)
            intervention = gr.Textbox(label="Intervention simulation", lines=4)
            modern = gr.Textbox(label="Modern layer integration", lines=4)
            output_image = gr.Image(label="Generated system canvas", type="pil")

    run.click(
        fn=analyze_ui,
        inputs=[text, image, location],
        outputs=[title, spatial_snapshot, hidden_patterns, leonardo_view, intervention, modern, output_image],
    )

if __name__ == "__main__":
    demo.launch(server_name=settings.host, server_port=settings.port)

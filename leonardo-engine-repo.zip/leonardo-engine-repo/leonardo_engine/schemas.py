from __future__ import annotations

from pydantic import BaseModel, Field


class AnalyzeResponse(BaseModel):
    title: str = Field(...)
    spatial_snapshot: str = Field(...)
    hidden_patterns: str = Field(...)
    temporal_evolution: str = Field(...)
    leonardo_view: str = Field(...)
    intervention_simulation: str = Field(...)
    modern_layer_integration: str = Field(...)
    latent_summary: str = Field(...)
    generated_image_base64: str = Field(...)

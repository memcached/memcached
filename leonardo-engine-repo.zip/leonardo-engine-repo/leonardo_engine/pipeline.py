from __future__ import annotations

from dataclasses import dataclass

from PIL import Image

from .generation import GenerationEngine
from .maps import location_snapshot
from .perception import PerceptionEngine
from .simulation import SimulationEngine
from .utils import image_to_base64


@dataclass
class LeonardoResult:
    title: str
    spatial_snapshot: str
    hidden_patterns: str
    temporal_evolution: str
    leonardo_view: str
    intervention_simulation: str
    modern_layer_integration: str
    latent_summary: str
    generated_image: Image.Image
    generated_image_base64: str
    source_kind: str

    def to_response(self):
        from .schemas import AnalyzeResponse

        return AnalyzeResponse(
            title=self.title,
            spatial_snapshot=self.spatial_snapshot,
            hidden_patterns=self.hidden_patterns,
            temporal_evolution=self.temporal_evolution,
            leonardo_view=self.leonardo_view,
            intervention_simulation=self.intervention_simulation,
            modern_layer_integration=self.modern_layer_integration,
            latent_summary=self.latent_summary,
            generated_image_base64=self.generated_image_base64,
        )


class LeonardoEngine:
    def __init__(self) -> None:
        self.perception = PerceptionEngine()
        self.generator = GenerationEngine()
        self.simulator = SimulationEngine()

    def analyze(self, *, text: str = "", image=None, location: str = "") -> LeonardoResult:
        perception = self.perception.perceive(text=text, image=image, location=location)

        if location.strip():
            map_snapshot = location_snapshot(location.strip())
            spatial_snapshot = f"Location anchor: {location.strip()}. {map_snapshot.note}."
            modern_layer = (
                f"Google Maps layer: {map_snapshot.url if map_snapshot.url else 'not enabled'}; "
                f"ready for routing, POIs, and traffic overlays."
            )
        else:
            spatial_snapshot = f"Input interpreted as {perception.source_kind}. {perception.caption}"
            modern_layer = "Modern layer integration: route analytics, POI overlays, and live map tiles can be attached here."

        hidden_patterns = (
            f"Detected cues: {', '.join(perception.cues)}. "
            f"Palette compression: {', '.join(perception.palette)}."
        )

        temporal_evolution = (
            "This system should be read as something that evolved through accumulation, constraint, "
            "and repeated recomposition rather than as a static object."
        )

        leonardo_view = (
            "Reduce the whole scene to lines, nodes, and surfaces. "
            f"Lines: {perception.cues[0] if perception.cues else 'flow'}; "
            f"Nodes: {perception.cues[1] if len(perception.cues) > 1 else 'junctions'}; "
            f"Surfaces: {perception.cues[2] if len(perception.cues) > 2 else 'fields'}."
        )

        intervention_simulation = (
            "Minimal intervention strategy: change one high-leverage boundary, compare before/after flow, "
            "and verify whether congestion or ambiguity moves to a different location."
        )

        latent_summary = (
            f"Latent abstraction derived from {perception.source_kind}: "
            f"{perception.caption.lower()} | cues: {', '.join(perception.cues)}"
        )

        generation_prompt = (
            f"{perception.caption}. "
            f"Structure cues: {', '.join(perception.cues)}. "
            f"Use clear geometry, layered flow lines, and restrained technical aesthetics."
        )

        gen = self.generator.generate(generation_prompt)
        sim = self.simulator.simulate(perception.caption, perception.cues, size=gen.image.size)

        final = Image.blend(gen.image.convert("RGB"), sim.image.convert("RGB"), alpha=0.28)
        base64_img = image_to_base64(final)

        title = "Leonardo Engine Analysis"

        return LeonardoResult(
            title=title,
            spatial_snapshot=spatial_snapshot,
            hidden_patterns=hidden_patterns,
            temporal_evolution=temporal_evolution,
            leonardo_view=leonardo_view,
            intervention_simulation=intervention_simulation,
            modern_layer_integration=modern_layer,
            latent_summary=latent_summary,
            generated_image=final,
            generated_image_base64=base64_img,
            source_kind=perception.source_kind,
        )

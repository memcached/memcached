from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import quote_plus

from PIL import Image

from .config import settings
from .utils import create_placeholder_canvas


@dataclass
class MapSnapshot:
    url: str
    image: Image.Image
    note: str


def google_static_map_url(location: str, zoom: int = 15, size: str = "1024x768") -> str:
    if not settings.google_maps_api_key:
        return ""
    query = quote_plus(location)
    return (
        "https://maps.googleapis.com/maps/api/staticmap"
        f"?center={query}&zoom={zoom}&size={size}&maptype=roadmap&key={settings.google_maps_api_key}"
    )


def location_snapshot(location: str) -> MapSnapshot:
    url = google_static_map_url(location)
    if not url:
        image = create_placeholder_canvas(
            f"Map integration is configured through GOOGLE_MAPS_API_KEY.\n\nLocation: {location}\n\nThis canvas acts as the spatial stand-in.",
            size=(1024, 768),
        )
        return MapSnapshot(url="", image=image, note="Google Maps API key not configured")

    image = create_placeholder_canvas(
        f"Google Static Maps URL prepared for:\n\n{location}\n\n{url}",
        size=(1024, 768),
    )
    return MapSnapshot(url=url, image=image, note="Google Static Maps URL prepared")

from __future__ import annotations

from dataclasses import dataclass

from PIL import Image, ImageDraw, ImageFont

from .config import settings


@dataclass
class GenerationResult:
    image: Image.Image
    mode: str
    note: str


class GenerationEngine:
    def __init__(self) -> None:
        self._pipe = None

    def _try_load_pipe(self):
        if not settings.enable_diffusion:
            return None
        try:
            import torch
            from diffusers import StableDiffusionPipeline

            pipe = StableDiffusionPipeline.from_pretrained(
                settings.diffusion_model_id,
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            )
            pipe = pipe.to("cuda" if torch.cuda.is_available() else "cpu")
            return pipe
        except Exception:
            return None

    def generate(self, prompt: str, size: tuple[int, int] = (1024, 768)) -> GenerationResult:
        if self._pipe is None:
            self._pipe = self._try_load_pipe()

        if self._pipe is not None:
            try:
                out = self._pipe(prompt, num_inference_steps=20, guidance_scale=7.5).images[0]
                return GenerationResult(image=out.convert("RGB"), mode="diffusion", note="Stable Diffusion output")
            except Exception:
                pass

        return GenerationResult(
            image=self._fallback_canvas(prompt, size=size),
            mode="fallback",
            note="Deterministic canvas render; enable diffusion for GPU-backed synthesis",
        )

    def _fallback_canvas(self, prompt: str, size: tuple[int, int]) -> Image.Image:
        img = Image.new("RGB", size, (245, 245, 242))
        draw = ImageDraw.Draw(img)
        font = ImageFont.load_default()

        title = "Leonardo Engine | Generated System Canvas"
        draw.text((32, 24), title, fill=(25, 25, 25), font=font)

        words = [w for w in prompt.split() if w]
        lines = []
        line = []
        for word in words:
            line.append(word)
            if len(" ".join(line)) > 42:
                lines.append(" ".join(line))
                line = []
        if line:
            lines.append(" ".join(line))

        draw.multiline_text((32, 80), "\n".join(lines[:10]), fill=(55, 55, 55), font=font, spacing=6)

        for i in range(8):
            x0 = 70 + i * 100
            y0 = 240 + (i % 3) * 45
            draw.rectangle((x0, y0, x0 + 60, y0 + 60), outline=(40, 40, 40), width=2)
            draw.line((x0 + 60, y0 + 30, x0 + 100, y0 + 30), fill=(90, 90, 90), width=2)
        return img

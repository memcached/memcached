from __future__ import annotations

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Leonardo Engine"
    app_env: str = "development"
    log_level: str = "INFO"
    google_maps_api_key: str = ""

    enable_diffusion: bool = False
    enable_captioning: bool = False
    diffusion_model_id: str = "runwayml/stable-diffusion-v1-5"
    captioning_model_id: str = "Salesforce/blip-image-captioning-base"

    host: str = "0.0.0.0"
    port: int = 7860


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

from __future__ import annotations

from dataclasses import dataclass

from PIL import Image, ImageDraw

from .utils import stable_hash


@dataclass
class SimulationResult:
    summary: str
    image: Image.Image


class SimulationEngine:
    def simulate(self, perception_caption: str, cues: list[str], size: tuple[int, int] = (1024, 768)) -> SimulationResult:
        width, height = size
        image = Image.new("RGB", size, (250, 250, 246))
        draw = ImageDraw.Draw(image)

        seed = stable_hash(perception_caption + "|" + "|".join(cues))
        bands = 10
        for i in range(bands):
            x = int((i + 1) * width / (bands + 1))
            offset = ((seed >> (i * 3)) % 60) - 30
            draw.line((x, 0, x + offset, height), fill=(70, 70, 70), width=2)

        for i, cue in enumerate(cues[:4]):
            y = 120 + i * 120
            draw.ellipse((80, y, 140, y + 60), outline=(40, 40, 40), width=2)
            draw.text((170, y + 18), cue, fill=(40, 40, 40))

        summary = "Simulation suggests directional flows, node clustering, and pressure points where the system accumulates constraint."
        return SimulationResult(summary=summary, image=image)

from __future__ import annotations

from dataclasses import dataclass

from PIL import Image

from .config import settings
from .utils import dominant_palette, ensure_image, stable_hash


@dataclass
class PerceptionResult:
    caption: str
    palette: list[str]
    cues: list[str]
    source_kind: str


class PerceptionEngine:
    def __init__(self) -> None:
        self._captioner = None

    def _caption(self, image: Image.Image) -> str:
        if not settings.enable_captioning:
            return "A structured visual scene with layered geometry and compositional tension."

        try:
            if self._captioner is None:
                from transformers import pipeline

                self._captioner = pipeline(
                    "image-to-text",
                    model=settings.captioning_model_id,
                )
            output = self._captioner(image)
            if output and isinstance(output, list):
                text = output[0].get("generated_text", "").strip()
                if text:
                    return text
        except Exception:
            pass

        return "A structured visual scene with layered geometry and compositional tension."

    def perceive(self, *, text: str = "", image=None, location: str = "") -> PerceptionResult:
        source_kind = "text"
        cues: list[str] = []

        if image is not None:
            source_kind = "image"
            pil_image = ensure_image(image)
            caption = self._caption(pil_image)
            palette = dominant_palette(pil_image)
            cues.extend(self._derive_image_cues(caption, pil_image.size))
            return PerceptionResult(caption=caption, palette=palette, cues=cues, source_kind=source_kind)

        if location.strip():
            source_kind = "location"
            caption = f"Spatial context centered on {location.strip()}."
            palette = ["rgb(240,240,240)", "rgb(60,60,60)"]
            cues.extend(self._derive_location_cues(location))
            return PerceptionResult(caption=caption, palette=palette, cues=cues, source_kind=source_kind)

        clean = text.strip() or "an unspecified spatial system"
        caption = f"Conceptual analysis request about {clean}."
        palette = ["rgb(248,248,248)", "rgb(55,55,55)"]
        cues.extend(self._derive_text_cues(clean))
        return PerceptionResult(caption=caption, palette=palette, cues=cues, source_kind=source_kind)

    def _derive_text_cues(self, text: str) -> list[str]:
        seed = stable_hash(text)
        buckets = [
            "flow",
            "density",
            "boundary",
            "hierarchy",
            "rhythm",
            "compression",
            "threshold",
            "trajectory",
        ]
        return [buckets[(seed >> (i * 3)) % len(buckets)] for i in range(4)]

    def _derive_image_cues(self, caption: str, size: tuple[int, int]) -> list[str]:
        w, h = size
        ratio = w / max(h, 1)
        aspect = "wide" if ratio > 1.15 else "tall" if ratio < 0.85 else "balanced"
        return [aspect, "visual structure", "layered edges", caption.split()[0].lower() if caption else "form"]

    def _derive_location_cues(self, location: str) -> list[str]:
        seed = stable_hash(location)
        buckets = ["connectivity", "corridor", "nodes", "infrastructure", "drainage", "activity", "frontier"]
        return [buckets[(seed >> (i * 4)) % len(buckets)] for i in range(4)]

from __future__ import annotations

import base64
import io
import hashlib
from typing import Any

import numpy as np
from PIL import Image, ImageDraw, ImageFont


def ensure_image(image: Any | None, size: tuple[int, int] = (1024, 768)) -> Image.Image:
    if image is None:
        return create_placeholder_canvas("No image supplied", size=size)

    if isinstance(image, Image.Image):
        return image.convert("RGB")

    if isinstance(image, (bytes, bytearray)):
        return Image.open(io.BytesIO(image)).convert("RGB")

    raise TypeError(f"Unsupported image type: {type(image)!r}")


def image_to_base64(image: Image.Image) -> str:
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def create_placeholder_canvas(text: str, size: tuple[int, int] = (1024, 768)) -> Image.Image:
    img = Image.new("RGB", size, (245, 245, 242))
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()
    title = "Leonardo Engine"
    draw.text((40, 40), title, fill=(25, 25, 25), font=font)
    draw.multiline_text((40, 90), text, fill=(60, 60, 60), font=font, spacing=4)
    return img


def stable_hash(text: str) -> int:
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return int(digest[:12], 16)


def dominant_palette(image: Image.Image, max_colors: int = 4) -> list[str]:
    arr = np.array(image.resize((128, 128)).convert("RGB"))
    pixels = arr.reshape(-1, 3)
    buckets: dict[tuple[int, int, int], int] = {}
    for r, g, b in pixels[::4]:
        key = (r // 32, g // 32, b // 32)
        buckets[key] = buckets.get(key, 0) + 1
    top = sorted(buckets.items(), key=lambda kv: kv[1], reverse=True)[:max_colors]
    return [f"rgb({k[0]*32},{k[1]*32},{k[2]*32})" for k, _ in top]
